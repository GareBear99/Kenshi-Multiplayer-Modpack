// DX11 generic sampler
SamplerState g_samLinear
{
    Filter = MIN_MAG_MIP_POINT;
    AddressU = Wrap;
    AddressV = Wrap;
};

// buffers/textures
uniform Texture2D imageTexture : register(t0);

float4 main
(
	float4 posIn	: SV_Position ,
	float2 texCoord0	: TEXCOORD0,
    uniform float satFactor
) : SV_Target
{
    // Get the color.
    float4 c0 = imageTexture.Sample(g_samLinear, texCoord0); 
    
	float luminance = (c0.r+c0.g+c0.b)/3;

	//Saturate
	float4 RT = c0 * satFactor + (1-satFactor)*luminance;
    
	return RT;
}