:: Upgrade all mesh files to Ogre3d 1.12.13 (14. August 2021)
: intro
@Echo off
Echo Hello, this is the installator for the Steam Mesh Updater [version 2.0].
Echo The installation will begin once you press ANY KEY, The process cannot be interrupted.
Echo Once you're ready, press a key and wait. The updater will close itself automatically.
Echo Have a good day and thanks for trying my mod! SCARaw
pause
: check
SET STEAM=../../../workshop/content/233860
:steam
Echo Good news i found you are using Steam version of the game
Echo Now i will try to scan all your steam workshop mods and fix them (most of them might even continue working)
Echo (warning this tool is very dumb and if by any miracle this is not steam version of the game CLICK big X or ESC)
pause
  for /r "%STEAM%" %%a in (*.mesh) do (
  echo Found %%a
  start /b OgreMeshUpgrader -t "%%a" >nul 2>&1)

Echo Thank you for your time and have a good time playing
pause
:done