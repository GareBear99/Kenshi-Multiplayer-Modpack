:: Upgrade all mesh files to Ogre3d 1.12.13 (14. August 2021)
: intro
@Echo off
Echo Hello, this is the installator for the Kenshi Mesh Updater [version 2.0].
Echo The installation will begin once you press ANY KEY, The process cannot be interrupted.
Echo Once you're ready, press a key and wait. The updater will close itself automatically.
Echo Have a good day and thanks for trying my mod! SCARaw
pause
: check
SET KENSHI=..
if exist "%KENSHI%\kenshi_x64.exe" goto :install
if exist "%KENSHI%\kenshi_GOG_x64.exe" goto :install
if exist "%KENSHI%\kenshi.exe" goto :install
Echo Could not find the kenshi executable, make sure to place Updater inside Kenshi location
goto :error
:install
  for /r "%KENSHI%" %%a in (*.mesh) do (
  echo Found %%a
  start /b OgreMeshUpgrader -t "%%a" >nul 2>&1)

Echo i added the pause at the end so you can scroll up and inspect the changes if you want to
Echo thank you for trying my mod and have fun playing your FASTER kenshi :)
pause
:done
goto :eof

:error
Echo something fucked
pause
:done