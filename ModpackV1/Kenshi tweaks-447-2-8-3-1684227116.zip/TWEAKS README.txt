In vanilla game hive soldiers are the only ones having no means of protecting themselves from the gass. I couldn't find a mod to fix that at a time so i started this one which is hopefully both first time players friendly and ads some value for returning players.

INSTALLATION:

UZIP TO THE "MODS" FOLDER IN YOR KENSHI MAIN FOLDER. CHECK THE MOD IN THE MOD LIST IN THE LAUNCHER.
MOD WORKS ON EXISTING SAVES BUT SOME CHANGES WONT TAKE AN EFFECT UNTIL YOU START A NEW GAME.
ENJOY!

LIST OF CHANGES:

RACES:

Animals:

- less flat hit point and hit chance numbers on body parts, depending on size, placement and such.
- Nomads have gorilla pups for sale.
- Added goat and dog backapcks to travel stores.
- Cage Beast digged out from the unused assets and added to some regions resized and renamed as it looks nothing
  like Cage...
- Tweaked stats on most animals (inluding hunger values - playing beastmaster is not tedious anymore!).
  Exaples:
  - dogs run faster but do less damage to robots and heavy armor
  - spiders (especially blood ones) have their attack reach reduced to match the animations and do reduced damage to robots
    and heavy armor
  - beak things run slower so fast characters can outrun them now
  - Crabs are tougher, bit faster and most attacks do reduced damage to them
  - pack animals and their wild relatives are more dangerous in combat

Hivers:

- Added new playable subrace: Hive Titan - a soldierlike specialised melee tank.
- Body parts HP increased slightly for princes and workers, chest HP for soldiers. Rebalanced
  skill bonusses and penalties, run speed and sight range. (workers finally get some love, beep!)
- Workers and princes cannot wear metal helmets which collide with their horns.
- Added armored gas mask wearable by hive soldiers and titans which offers protection from gass.
  Masks and their blueprints are avaliable at general stores in Hive villages.

Greenlander:

- Revised skill bonusses so they are better workers/crafters.

Scorchlander:

- Revised skills and stats so they are better suited for and adventurer play style than a settler one.
- Compared to Greenlanders  they  have less HP but heal  and run faster, are more agile and peceptive.
- They dont eat raw meat anymore. Have some manners!

Shek:

- Shek people cannot wear metal helmets that collide with their horns but have their head HP increased.
- Shek people can now eat raw meat. Damn brutes...
- Different stats and skills for Shek men and women. While men are well suited to be melee tanks but are bad at anything
  else, women are less tough  but more well rounded.
IMPORTANT: to play a Shek famale you need to select female subrace then select female gender, otherwise clothes
and armor will appear incorrectly on them. Kinda roundabout sollution to editor limitations.
Will not mess unmodded saves.

Skeletons:

- Divided skeleton race to 6 playable subraces with different looks skills and stats. Agnu is still a unique one.
- All robots (including spiderbots) are tougher, most attacks do reduced damage to them but they heal slower.

FACTIONS:

- Some unique characters like faction leaders or high bounty targets have gear on them thas is unique by stats and name.
- Faction elite soldiers generally wear better quality equipment and have better stats.
- United Cities conscripts and scouts wield ranged weaponry now. All UC military is skilled in ranged combat. Patrols
  and armies have their numbers  increased and consist some heavy samurai now.
- Holy nation patrols and armies have less elites but the fodder troops are slightly more skilled and some of them wear
  chainshirts under their clothes.
- Shek men and women fill different roles in their kingdom military according to their new skills and stats.
- Minor tweaks on bandit faction gear and skills.

ITEMS:

- Scrapped the whole mechanics of cut to blunt damage convertion on armor. Main reason being that in some cases due
  to blunt damage after convertion  not being reduced further by armor characters took more damage by wearing more
  layers of protection than by wearing only one (there should be a mod on  Nexus which adresses just that and explains
  the fault of the system in more detail).
- Coverage, protection and skill penalties/bonusses tweaked on most armor to make more choices viable.
- Melee weapons damage, skill bonuses/penalties, armor penetration, weight and reach rebalanced, hopefuly making each
  weapon choice both viable and  distinct.
- Added a two hander in blunt weapon category. Inventory icons are off (no idea how to fix it�) but 3d model and gameplay
  works fine.
- Crossbows do reduced damage to giant animals, robots and crabs depending on the bolt size (smaller the bolt, bigger the
  reduction).
- Rebalanced the nutricion values and prices of food items better reflecting the resouces needed to produce them.

OTHER:

- Extra damage taken due to low toughness decreased from 65% extra ant 0 toughness to 35% to prevents low level
  characters from dying as easily as before.
  Damage reduction at 100 toughness unchanged.
- Carrying bodies encumbers characters more.
- There was a tree in Shark blocking entrance to one of the shops. Fixed it.
- Martial arts damage reduced by 20%. Bare fists (non-robotic) do reduced damage to armor and  robots (its still very
  powerful, you just need more skill to  oneshot someone now).
- Few minor changes/tweaks/rebalnces sprinkled around the world (of Kenshi).